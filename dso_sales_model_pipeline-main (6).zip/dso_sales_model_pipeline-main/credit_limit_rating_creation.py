import os
import sys
import pdb
import warnings
import datetime
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

import config_connection_varirables
from config_connection_varirables import conn, logger, to_date, schema_name
from model_inputs_dissection import obligors_to_exclude, obligors_to_score

warnings.filterwarnings('ignore')

# Input Files
sales_oos = 'sales_model/data/9_final_model/out_sample_scored_output.csv'
dso_oos = 'dso_model/data/9_final_model/out_sample_scored_output.csv'
sales_forecast = 'Data/Model Inputs/sales_forecast_data.csv'

# Output Files
ratings_file = 'Data/Output/scored_ratings.csv'
order_block_file = 'Data/Output/scored_ratings_order_block_report.csv'
full_output = 'Data/Output/full_output.csv'

# Check for Data Errors
def check_errors(sales, dso):
    # Get the Max Snap From DSO Prediction
    dso_max_invoice = int(dso.invoice_yyyymm.max())

    # Get the Max Snap From DSO Prediction
    sales_max_invoice = int(sales.invoice_yyyymm.max())

    # Check the Max Snaps of the DSO & SALES Predictions
    if dso_max_invoice != sales_max_invoice:
        print("MAX SNAPS OF DSO & SALES FILE DO NOT MATCH. \nEXITING THE PROGRAM. \nRECHECK THE FILES")
        sys.exit()
    
    # Convert the to_date to snap
    to_date_snap = int(datetime.strftime(datetime.strptime(to_date, '%Y-%m-%d'), '%Y%m'))

    # Check the Max Snap with the To Date
    if dso_max_invoice != to_date_snap:
        print("MAX SNAPS OF DSO DO NOT MATCH WITH THE TO_DATE PROVIDED. \nEXITING THE PROGRAM. \nRECHECK THE FILES")
        sys.exit()

    return

# Load the input files and Preprocess the data
def load_preprocess_data():
    # Load Input Files
    df_sales = pd.read_csv(sales_oos, usecols = ['obligor_code', 'invoice_yyyymm', 'next_2m_sales_pred'])
    df_dso = pd.read_csv(dso_oos, usecols = ['obligor_code', 'invoice_yyyymm', 'dso_next_2m_pred'])
    df_sales_forecast = pd.read_csv(sales_forecast, usecols = ['obligor_code', 'invoice_yyyymm', 'sales_6m', 'sales', 'collections', 'balance', 'beyond_max_snap'])

    # Check the data for Errors
    check_errors(df_sales, df_dso)
    
    # Rename the Predicted OOS
    df_sales = df_sales.rename(columns={'next_2m_sales_pred':'sales_pred'})
    print("\n\nShape of OOS Sales Data: ", df_sales.shape)
    print("\nObligor Count of OOS Sales Data: ", df_sales.obligor_code.nunique())
    logger.debug("\n\nShape of OOS Sales Data: %s", df_sales.shape)
    logger.debug("\nObligor Count of OOS Sales Data: %s", df_sales.obligor_code.nunique())
    df_dso = df_dso.rename(columns={'dso_next_2m_pred':'dso_pred'})
    print("\n\nShape of OOS DSO Data: ", df_dso.shape)
    print("Obligor Count of OOS DSO Data: ", df_dso.obligor_code.nunique())
    logger.debug("\n\nShape of OOS DSO Data: %s", df_dso.shape)
    logger.debug("\nObligor Count of OOS DSO Data: %s", df_dso.obligor_code.nunique())

    # Merging the Files
    df = pd.merge(df_sales, df_dso, how='left', left_on=['obligor_code','invoice_yyyymm'], right_on = ['obligor_code', 'invoice_yyyymm'])
    print("\n\nShape of Merged Sales & DSO Data: ", df.shape)
    print("Obligor Count of Merged Sales & DSO Data: ", df.obligor_code.nunique())
    df = pd.merge(df, df_sales_forecast, how='left', left_on=['obligor_code','invoice_yyyymm'], right_on = ['obligor_code', 'invoice_yyyymm'])
    print("\n\nShape of Merged Sales, DSO & sales forecast Data: ", df.shape)
    print("Obligor Count of Merged Sales, DSO & sales forecast Data: ", df.obligor_code.nunique())
    logger.debug("\n\nShape of Merged Sales, DSO & sales forecast Data: %s", df.shape)
    logger.debug("\nObligor Count of Merged Sales, DSO & sales forecast Data: %s", df.obligor_code.nunique())

    # Create Date Field For the Production System
    df['date'] = pd.to_datetime(df['invoice_yyyymm'], format='%Y%m')
    df['date'] = df['date'] + pd.DateOffset(months=1)
    df['date'] = df['date'].dt.date

    return df, df_sales_forecast

# Assigning Credit Segments & Recommended Credit Limit
def credit_segment(df):
    print("\n\nShape of Merged Data before assigning credit segments: ", df.shape)
    print("Obligor Count of Merged Data before assigning credit segments: ", df.obligor_code.nunique())
    df['obligor_code'] = df['obligor_code'].astype(str)
    df['group'] = df['obligor_code'].str.slice(0,2)
    df['group'] = df['group'].astype(int)
    df['trade_flag'] = np.where(df['group'].isin([50,60]),1,0)
    df['govt_flag'] = np.where(df['group'].isin([40]),1,0)
    df['ib_flag'] = np.where(df['group'].isin([70]),1,0)
    df['obligor_code'] = df['obligor_code'].astype(object)

    df['sales_rolling2m_avg_pred'] = df['sales_pred']/(2*1e5)

    # Segment Data Frame creation
    df_trade = df[df['trade_flag'] == 1]
    df_govt = df[df['govt_flag'] == 1]
    df_ib = df[df['ib_flag'] == 1]

    print("\n\nShape of Trade Segment Data: ", df_trade.shape)
    print("Obligor Count of Trade Segment Data: ", df_trade.obligor_code.nunique())
    print("\n\nShape of Govt Segment Data: ", df_govt.shape)
    print("Obligor Count of Govt Segment Data: ", df_govt.obligor_code.nunique())
    print("\n\nShape of IB Segment Data: ", df_ib.shape)
    print("Obligor Count of IB Segment Data: ", df_ib.obligor_code.nunique())

    ###################################################################
    ##################### GOVT - DSO & Sales Grid #####################
    ###################################################################

    df_govt['trade_govt_ib_seg'] = 1
    df_govt['dso_pred_group'] = np.where(df_govt['dso_pred'] <= 120, 0, (np.where(df_govt['dso_pred'] <= 180, 1, 2)))
    df_govt['predicted_sales_2m_group'] = np.where(df_govt['sales_rolling2m_avg_pred'] <= 5, 0, (np.where(df_govt['sales_rolling2m_avg_pred'] <= 20, 1, 2)))
    df_govt['g_t_i_seg_sales_dso_group'] = 100*df_govt['trade_govt_ib_seg'] + 10*df_govt['predicted_sales_2m_group'] + 1*df_govt['dso_pred_group']

    # Assigning Sales Multiplier
    df_govt['sales_multiplier'] = np.where(df_govt['g_t_i_seg_sales_dso_group'].isin([100]),4,1)
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([110])),3,df_govt['sales_multiplier'])
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([120])),2,df_govt['sales_multiplier'])
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([101])),2.5,df_govt['sales_multiplier'])
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([111])),1.5,df_govt['sales_multiplier'])
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([121])),0.5,df_govt['sales_multiplier'])
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([102,112,122])),0,df_govt['sales_multiplier'])
    
    # Creating Credit Limit Model
    df_govt['recommended_credit_limit'] = df_govt['sales_multiplier']*df_govt['sales_rolling2m_avg_pred']*1e5
    df_govt['recommended_credit_limit'] = df_govt['recommended_credit_limit'].round(decimals=-4)
    
    ###################################################################
    ##################### TRADE - DSO & Sales Grid ####################
    ###################################################################

    df_trade['trade_govt_ib_seg'] = 2
    df_trade['dso_pred_group'] = np.where(df_trade['dso_pred'] <= 60, 0, (np.where(df_trade['dso_pred'] <= 90, 1, 2)))
    df_trade['predicted_sales_2m_group'] = np.where(df_trade['sales_rolling2m_avg_pred'] <= 1, 0, (np.where(df_trade['sales_rolling2m_avg_pred'] <= 5,1,2)))
    df_trade['g_t_i_seg_sales_dso_group'] = 100*df_trade['trade_govt_ib_seg'] + 10*df_trade['predicted_sales_2m_group'] + 1*df_trade['dso_pred_group']

    # Assigning Sales Multiplier
    df_trade['sales_multiplier'] = np.where(df_trade['g_t_i_seg_sales_dso_group'].isin([202, 212, 222]),0,2)
    # df_trade['sales_multiplier'] = np.where(df_trade['g_t_i_seg_sales_dso_group'].isin([200]),1.5,1)
    # df_trade['sales_multiplier'] = np.where((df_trade['g_t_i_seg_sales_dso_group'].isin([210])),1,df_trade['sales_multiplier'])
    # df_trade['sales_multiplier'] = np.where((df_trade['g_t_i_seg_sales_dso_group'].isin([220])),0.8,df_trade['sales_multiplier'])
    # df_trade['sales_multiplier'] = np.where((df_trade['g_t_i_seg_sales_dso_group'].isin([201])),0.8,df_trade['sales_multiplier'])
    # df_trade['sales_multiplier'] = np.where((df_trade['g_t_i_seg_sales_dso_group'].isin([211,221])),0.5,df_trade['sales_multiplier'])
    # df_trade['sales_multiplier'] = np.where((df_trade['g_t_i_seg_sales_dso_group'].isin([202,212,222])),0,df_trade['sales_multiplier'])
    
    # Creating Credit Limit Model
    df_trade['recommended_credit_limit'] = df_trade['sales_multiplier']*df_trade['sales_rolling2m_avg_pred']*1e5
    df_trade['recommended_credit_limit'] = df_trade['recommended_credit_limit'].round(decimals=-4)

    ###################################################################
    ####################### IB - DSO & Sales Grid #####################
    ###################################################################
    
    df_ib['trade_govt_ib_seg'] = 3
    df_ib['dso_pred_group'] = np.where(df_ib['dso_pred'] <= 90, 0, 1)
    df_ib['predicted_sales_2m_group'] = np.where(df_ib['sales_rolling2m_avg_pred'] <= 5, 0, (np.where(df_ib['sales_rolling2m_avg_pred'] <= 20, 1, 2)))
    df_ib['g_t_i_seg_sales_dso_group'] = 100*df_ib['trade_govt_ib_seg'] + 10*df_ib['predicted_sales_2m_group'] + 1*df_ib['dso_pred_group']

    # Assigning Sales Multiplier
    df_ib['sales_multiplier'] = np.where(df_ib['g_t_i_seg_sales_dso_group'].isin([300]),3,1)
    df_ib['sales_multiplier'] = np.where((df_ib['g_t_i_seg_sales_dso_group'].isin([310])),2,df_ib['sales_multiplier'])
    df_ib['sales_multiplier'] = np.where((df_ib['g_t_i_seg_sales_dso_group'].isin([320])),1.2,df_ib['sales_multiplier'])
    df_ib['sales_multiplier'] = np.where((df_ib['g_t_i_seg_sales_dso_group'].isin([301])),1.5,df_ib['sales_multiplier'])
    df_ib['sales_multiplier'] = np.where((df_ib['g_t_i_seg_sales_dso_group'].isin([311])),1,df_ib['sales_multiplier'])
    df_ib['sales_multiplier'] = np.where((df_ib['g_t_i_seg_sales_dso_group'].isin([321])),0,df_ib['sales_multiplier'])
    
    # Creating Credit Limit Model
    df_ib['recommended_credit_limit'] = df_ib['sales_multiplier']*df_ib['sales_rolling2m_avg_pred']*1e5
    df_ib['recommended_credit_limit'] = df_ib['recommended_credit_limit'].round(decimals=-4)

    # Concat all the Dataframes
    df_final = pd.concat([df_govt, df_trade, df_ib], ignore_index=True, join='outer', sort=False)

    # Floor & Cap Recommended Credit Limit
    df_final['recommended_credit_limit'] = np.where((df_final['govt_flag'] == 1) & (df_final['recommended_credit_limit'] > 7500000), 7500000, df_final['recommended_credit_limit'])
    df_final['recommended_credit_limit'] = np.where((df_final['trade_flag'] == 1) & (df_final['recommended_credit_limit'] > 7500000), 7500000, df_final['recommended_credit_limit'])
    df_final['recommended_credit_limit'] = np.where((df_final['ib_flag'] == 1) & (df_final['recommended_credit_limit'] > 7500000), 7500000, df_final['recommended_credit_limit'])
    df_final['recommended_credit_limit'] = np.where(df_final['recommended_credit_limit'] <= 0, 1, df_final['recommended_credit_limit'])
    
    logger.debug("\nRecommended Credit Limit Capped and Floored")
    print('\nRecommended Credit Limit Capped and Floored')

    print('\nCredit Segment created')
    print("\n\nShape of Merged Data after adding Credit Segment: ", df_final.shape)
    print("Obligor Count of Merged Data after adding Credit Segment: ", df_final.obligor_code.nunique())
    logger.debug("\n\nCredit Segment Created")
    logger.debug("\nShape of Merged Data after adding Credit Segment: %s", df_final.shape)
    logger.debug("\nObligor Count of Merged Data after adding Credit Segment: %s", df_final.obligor_code.nunique())

    return df_final

# Assign Risk and Risk Ratings
def assign_ratings(df):
    bins = list(range(0,351,10))
    bins = [-1] + bins
    df['rating_fiftytile'] = pd.cut(df['dso_pred'],bins=bins)
    df['rating_fiftytile_num'] = df['rating_fiftytile'].cat.codes
    five_scale_scaler = 7
    df['rating_5_scale'] = df['rating_fiftytile_num']/five_scale_scaler
    df['rating'] = None
    for i in df.index:
        if df.at[i,'govt_flag'] == 1:
            if df.at[i,'dso_pred'] <= 120:
                df.at[i,'rating'] = 1
            elif ((df.at[i,'dso_pred'] > 120) & (df.at[i,'dso_pred'] <= 180)):
                df.at[i,'rating'] = 2
            else:
                df.at[i,'rating'] = 3
        elif df.at[i, 'trade_flag'] == 1:
            if df.at[i,'dso_pred'] <= 60:
                df.at[i,'rating'] = 1
            elif ((df.at[i,'dso_pred'] > 60) & (df.at[i,'dso_pred'] <= 90)):
                df.at[i,'rating'] = 2
            else:
                df.at[i,'rating'] = 3
        else:
            if df.at[i,'dso_pred'] <= 90:
                df.at[i,'rating'] = 1
            else:
                df.at[i,'rating'] = 3

    print('\nRatings Assigned')
    print("\n\nShape of Merged Data after Assign Ratings & Rating 5 Scale: ", df.shape)
    print("Obligor Count of Merged Data after Assign Ratings & Rating 5 Scale: ", df.obligor_code.nunique())
    logger.debug("\n\nRatings Assigned")

    return df

# Get the previous Order block report & the New Order Block Report
def get_order_block_reports(df, active_customers):
    # Get the Order Block Report
    df_order_block_report = df[['obligor_code', 'date', 'rating', 'rating_5_scale', 'recommended_credit_limit', 'dso_pred', 'sales_pred', 'sales_multiplier']]
    df_order_block_report['degraded'] = np.NaN
    print("\n\nShape of Predicted Order Block Data: ", df_order_block_report.shape)
    print("Obligor Count of Predicted Order Block Data: ", df_order_block_report.obligor_code.nunique())
    logger.debug("\n\nShape of Predicted Order Block Data: %s", df_order_block_report.shape)
    logger.debug("\nObligor Count of Predicted Order Block Data: %s", df_order_block_report.obligor_code.nunique())

    # Check if the number of obligors to be scored is the same as forecasted
    if df_order_block_report.loc[df['date'] == df_order_block_report.date.max()].shape[0] != len(active_customers):
        config_connection_varirables.notify = True
    
    # Get the previous months Order Block Report
    prev_order_block_query = f"""select * from {schema_name}.model_outputs_copy;"""

    df_prev_order_block = pd.read_sql_query(sql=prev_order_block_query, con=conn)
    print(df_prev_order_block)
    print(df_prev_order_block.dtypes)

    #df_prev_order_block = pd.read_csv('Data/Output/scored_ratings_order_block_report.csv')
    #print(df_prev_order_block)
    df_prev_order_block['obligor_code']=df_prev_order_block['obligor_code'].astype('str') 
    
    
    # Create field to accomodate degradation If not Present in Model Outputs Copy <Previous Order Block Report>
    if 'degraded' not in df_prev_order_block:
        df_prev_order_block['degraded'] = np.NAN

    print("\n\nShape of Previous Predicted Order Block Data: ", df_prev_order_block.shape)
    print("Obligor Count of Previous Predicted Order Block Data: ", df_prev_order_block.obligor_code.nunique())
    logger.debug("\n\nShape of Previous Predicted Order Block Data: %s", df_prev_order_block.shape)
    logger.debug("\nObligor Count of Previous Predicted Order Block Data: %s", df_prev_order_block.obligor_code.nunique())

    return df_order_block_report, df_prev_order_block

# Degrade recommended credit limit & Update the sales_multiplier
def degrade(df):
    # Create Flags to Identify Segments & sales_rolling2m_avg_pred
    df['group'] = df['obligor_code'].str.slice(0,2)
    df['trade_flag'] = np.where(df['group'].isin(['50','60']),1,0)
    df['govt_flag'] = np.where(df['group'].isin(['40']),1,0)
    df['ib_flag'] = np.where(df['group'].isin(['70']),1,0)
    df['sales_rolling2m_avg_pred'] = df['sales_pred']/(2*1e5)

    # Segment Data Frame creation
    df_trade = df[df['trade_flag'] == 1]
    df_govt = df[df['govt_flag'] == 1]
    df_ib = df[df['ib_flag'] == 1]

    print("Number of Trade Customers to be degraded: ", df_trade.obligor_code.nunique())
    print("Number of GOVT Customers to be degraded: ", df_govt.obligor_code.nunique())
    print("Number of IB Customers to be degraded: ", df_ib.obligor_code.nunique())

    ###################################################################
    ##################### GOVT - DSO & Sales Grid #####################
    ###################################################################

    df_govt['trade_govt_ib_seg'] = 1
    df_govt['dso_pred_group'] = np.where(df_govt['dso_pred'] <= 120, 0, (np.where(df_govt['dso_pred'] <= 180, 1, 2)))
    df_govt['predicted_sales_2m_group'] = np.where(df_govt['sales_rolling2m_avg_pred'] <= 5, 0, (np.where(df_govt['sales_rolling2m_avg_pred'] <= 20, 1, 2)))
    df_govt['g_t_i_seg_sales_dso_group'] = 100*df_govt['trade_govt_ib_seg'] + 10*df_govt['predicted_sales_2m_group'] + 1*df_govt['dso_pred_group']

    # Assigning Sales Multiplier
    df_govt['sales_multiplier'] = np.where(df_govt['g_t_i_seg_sales_dso_group'].isin([100, 110, 120]), 0.25,0)
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([101, 111, 121])),0.15,df_govt['sales_multiplier'])
    df_govt['sales_multiplier'] = np.where((df_govt['g_t_i_seg_sales_dso_group'].isin([102, 112, 122])),0,df_govt['sales_multiplier'])
    
    # Creating Credit Limit Model
    df_govt['recommended_credit_limit'] = df_govt['sales_multiplier'] * df_govt['recommended_credit_limit']
    df_govt['recommended_credit_limit'] = df_govt['recommended_credit_limit'].round(decimals=-4)
    
    ###################################################################
    ##################### TRADE - DSO & Sales Grid ####################
    ###################################################################

    df_trade['trade_govt_ib_seg'] = 2
    df_trade['dso_pred_group'] = np.where(df_trade['dso_pred'] <= 45, 0, (np.where(df_trade['dso_pred'] <= 60, 1, 2)))
    df_trade['predicted_sales_2m_group'] = np.where(df_trade['sales_rolling2m_avg_pred'] <= 1, 0, (np.where(df_trade['sales_rolling2m_avg_pred'] <= 5,1,2)))
    df_trade['g_t_i_seg_sales_dso_group'] = 100*df_trade['trade_govt_ib_seg'] + 10*df_trade['predicted_sales_2m_group'] + 1*df_trade['dso_pred_group']

    # Assigning Sales Multiplier
    df_trade['sales_multiplier'] = np.where(df_trade['g_t_i_seg_sales_dso_group'].isin([200, 210, 220]), 0.4, 0)
    df_trade['sales_multiplier'] = np.where((df_trade['g_t_i_seg_sales_dso_group'].isin([201, 211, 221])), 0.3, df_trade['sales_multiplier'])
    df_trade['sales_multiplier'] = np.where((df_trade['g_t_i_seg_sales_dso_group'].isin([202, 212, 222])),0, df_trade['sales_multiplier'])
    
    # Creating Credit Limit Model
    df_trade['recommended_credit_limit'] = df_trade['sales_multiplier']*df_trade['recommended_credit_limit']
    df_trade['recommended_credit_limit'] = df_trade['recommended_credit_limit'].round(decimals=-4)

    ###################################################################
    ####################### IB - DSO & Sales Grid #####################
    ###################################################################
    
    df_ib['trade_govt_ib_seg'] = 3
    df_ib['dso_pred_group'] = np.where(df_ib['dso_pred'] <= 90, 0, 1)
    df_ib['predicted_sales_2m_group'] = np.where(df_ib['sales_rolling2m_avg_pred'] <= 5, 0, (np.where(df_ib['sales_rolling2m_avg_pred'] <= 20, 1, 2)))
    df_ib['g_t_i_seg_sales_dso_group'] = 100*df_ib['trade_govt_ib_seg'] + 10*df_ib['predicted_sales_2m_group'] + 1*df_ib['dso_pred_group']

    # Assigning Sales Multiplier
    df_ib['sales_multiplier'] = np.where(df_ib['g_t_i_seg_sales_dso_group'].isin([300, 310, 320]),0.3,1)
    df_ib['sales_multiplier'] = np.where((df_ib['g_t_i_seg_sales_dso_group'].isin([301, 311, 321])),0,df_ib['sales_multiplier'])
    
    # Creating Credit Limit Model
    df_ib['recommended_credit_limit'] = df_ib['sales_multiplier']*df_ib['recommended_credit_limit']
    df_ib['recommended_credit_limit'] = df_ib['recommended_credit_limit'].round(decimals=-4)

    # Concat all the Dataframes
    df_final = pd.concat([df_govt, df_trade, df_ib], ignore_index=True, join='outer', sort=False)

    # Floor & Cap Recommended Credit Limit
    df_final['recommended_credit_limit'] = np.where((df_final['govt_flag'] == 1) & (df_final['recommended_credit_limit'] > 7500000), 7500000, df_final['recommended_credit_limit'])
    df_final['recommended_credit_limit'] = np.where((df_final['trade_flag'] == 1) & (df_final['recommended_credit_limit'] > 2500000), 2500000, df_final['recommended_credit_limit'])
    df_final['recommended_credit_limit'] = np.where((df_final['ib_flag'] == 1) & (df_final['recommended_credit_limit'] > 7500000), 7500000, df_final['recommended_credit_limit'])
    df_final['recommended_credit_limit'] = np.where(df_final['recommended_credit_limit'] <= 0, 1, df_final['recommended_credit_limit'])
    
    # Drop all the fields that are not necessary
    temp = ['group', 'trade_flag', 'govt_flag', 'ib_flag', 'sales_rolling2m_avg_pred', 'trade_govt_ib_seg'
            , 'dso_pred_group', 'predicted_sales_2m_group', 'g_t_i_seg_sales_dso_group']
    df_final.drop(temp, axis = 1, inplace = True)

    logger.debug("\nDegraded Recommended Credit Limit Capped and Floored")
    print('\nDegraded Recommended Credit Limit Capped and Floored')

    print('\nDegraded Recommended Credit Limit & Updated the Sales Multiplier')
    print("\n\nShape of Merged Data after Degrading Recommended Credit Limit & Updating the Sales Multiplier: ", df_final.shape)
    print("Obligor Count of Merged Data after Degrading Recommended Credit Limit & Updating the Sales Multiplier: ", df_final.obligor_code.nunique())
    logger.debug("\nShape of Merged Data after Degrading Recommended Credit Limit & Updating the Sales Multiplier: %s", df_final.shape)
    logger.debug("\nObligor Count of Merged Data after Degrading Recommended Credit Limit & Updating the Sales Multiplier: %s", df_final.obligor_code.nunique())

    return df_final

# Degrade the recommended credit limit
def degrade_credit_limits(df, current_snap):

    # Part 1 - Check if all the values in the degraded column is null or not
    if df['degraded'].isnull().sum()==df.shape[0]:
        # Update degraded field to True
        df['degraded'] = 1
        df['date'] = current_snap
        df_degraded = degrade(df)

    else:
        # Get all customers who have already been degraded & Update their date to the current snap
        customers_already_degraded = df[df['degraded'] == 1].reset_index(drop=True)
        customers_already_degraded['date'] = current_snap
        print('\nNumber of customers with already degraded credit limit: ', customers_already_degraded.obligor_code.nunique())
        logger.debug("\nNumber of Customers with already Degraded Credit Limit: %s", customers_already_degraded.obligor_code.nunique())

        # Get all customers who have not been degraded & Update their recommended credit limit, degraded & date to the current snap
        customers_not_degraded = df[df['degraded'].isnull()].reset_index(drop=True)
        customers_not_degraded['degraded'] = 1
        customers_not_degraded['date'] = current_snap
        customers_not_degraded = degrade(customers_not_degraded)
        print('\nNumber of customers whose credit limit got degraded in the current month: ', customers_not_degraded.obligor_code.nunique())
        logger.debug("\nNumber of Customers whose credit limit got degraded in the current month: %s", customers_not_degraded.obligor_code.nunique())

        # Combine both the tables & Sort Values
        df_degraded = pd.concat([customers_already_degraded, customers_not_degraded], ignore_index=True, join='outer', sort=False)
        df_degraded.sort_values(['obligor_code']).reset_index(drop=True)

    return df_degraded

# Old way of updating (Not used anymore) - Update previous month's Rating, ratings_5_scale, recommended_credit_limit, dso_pred, sales_pred, sales_multiplier
def old_update_recommendation(df_order_block_report, df_prev_order_block, df_sales):
    # Get Previous Month
    previous_month = df_prev_order_block.date.max()
    
    # Current Snap
    current_snap = df_order_block_report.date.max()

    # Get all Inactive Customers
    obl_exclude = obligors_to_exclude(df_sales)

    # Get all Active Customers
    active_customers = obligors_to_score(df_sales)

    ################################################################################################################
    # 1st part - Keep the old recommendations for everything prior to 2nd max date
    df_prev_order_block_till_max = df_prev_order_block[~(df_prev_order_block['date'] == previous_month)]

    ################################################################################################################
    # 2nd Part - Degrade the recommended credit limits for all the inactive customers

    # Get previous max snaps of all obligors to be excluded for degrading their credit limits
    df_obl_exclude = df_prev_order_block[df_prev_order_block['obligor_code'].isin(obl_exclude)].reset_index()
    df_obl_max_date = df_obl_exclude.groupby('obligor_code')['date'].max().reset_index()
    df_to_be_degraded = pd.merge(df_obl_exclude, df_obl_max_date, how='inner', on=['obligor_code', 'date'])

    # Degrade their credit limits
    df_degraded = degrade_credit_limits(df_to_be_degraded, current_snap)
    print("\nCustomers with Degraded Credit Limit: {}".format(df_degraded.obligor_code.nunique()))
    logger.debug("\nCustomers with Degraded Credit Limit: %s", df_degraded.obligor_code.nunique())

    ################################################################################################################
    # 3 - Update the previous recommendations with the new recommendations for 2nd max date 
    # And Keep the old predictions for the 2nd Max Date if no new recommendation present
    # Corner Case: If a customer was active last month & becomes inactive in the current month - 2nd Max Date predictions should still be considered 
    # from last month for the 2nd Max Date and for the final snap degrade the recommendation <Already Taken Care of>
    df_old_previous_month = df_prev_order_block[df_prev_order_block['date'] == previous_month]
    df_new_previous_month = df_order_block_report[(df_order_block_report['date'] == previous_month) & (df_prev_order_block['obligor_code'].isin(active_customers))]

    df_previous_month = pd.merge(df_old_previous_month, df_new_previous_month, 
                                on = ['obligor_code','date'], 
                                how='outer', 
                                suffixes=('_old', '_new'))

    # Updating old predictions with new predictions and keeping the old predictions where new predictions are not available for the 2nd Max Date
    df_previous_month['rating_new'] = np.where(df_previous_month['rating_new'].isnull(), df_previous_month['rating_old'], df_previous_month['rating_new'])
    df_previous_month['rating_5_scale_new'] = np.where(df_previous_month['rating_5_scale_new'].isnull(), df_previous_month['rating_5_scale_old'], df_previous_month['rating_5_scale_new'])
    df_previous_month['recommended_credit_limit_new'] = np.where(df_previous_month['recommended_credit_limit_new'].isnull(), df_previous_month['recommended_credit_limit_old'], df_previous_month['recommended_credit_limit_new'])
    df_previous_month['dso_pred_new'] = np.where(df_previous_month['dso_pred_new'].isnull(), df_previous_month['dso_pred_old'], df_previous_month['dso_pred_new'])
    df_previous_month['sales_pred_new'] = np.where(df_previous_month['sales_pred_new'].isnull(), df_previous_month['sales_pred_old'], df_previous_month['sales_pred_new'])
    df_previous_month['sales_multiplier_new'] = np.where(df_previous_month['sales_multiplier_new'].isnull(), df_previous_month['sales_multiplier_old'], df_previous_month['sales_multiplier_new'])
    df_previous_month['degraded_new'] = np.where(df_previous_month['sales_multiplier_new'].isnull(), df_previous_month['degraded_old'], df_previous_month['degraded_new'])

    print("\nNumber of Customers with Old Updated Credit Limit for the 2nd Max Date: {}".format(df_previous_month[~df_previous_month['rating_old'].isnull()].obligor_code.nunique()))
    logger.debug("\nNumber of Customers with Old Credit Limit for the 2nd Max Date: %s", df_previous_month[~df_previous_month['rating_old'].isnull()].obligor_code.nunique())

    print("\nNumber of Customers with New Updated Credit Limit for the 2nd Max Date: {}".format(df_previous_month[~df_previous_month['rating_new'].isnull()].obligor_code.nunique()))
    logger.debug("\nNumber of Customers with New Credit Limit for the 2nd Max Date: %s", df_previous_month[~df_previous_month['rating_new'].isnull()].obligor_code.nunique())

    print("\nNumber of Customers whose Credit Limit were updated for the 2nd Max Date: {}".format(df_previous_month.obligor_code.nunique()))
    logger.debug("\nNumber of Customers whose Credit Limit were updated for the 2nd Max Date: %s", df_previous_month.obligor_code.nunique())

    # renaming the columns
    df_previous_month = df_previous_month.rename(columns = {'rating_new':'rating', 'rating_5_scale_new':'rating_5_scale', 
                                                            'dso_pred_new':'dso_pred', 'sales_pred_new':'sales_pred',
                                                            'recommended_credit_limit_new':'recommended_credit_limit', 
                                                            'sales_multiplier_new':'sales_multiplier',
                                                            'degraded_new':'degraded'})

    df_previous_month = df_previous_month[['obligor_code', 'date', 'rating', 'rating_5_scale', 'recommended_credit_limit', 
                                            'dso_pred', 'sales_pred', 'sales_multiplier', 'degraded']]
    
    ################################################################################################################
    # 4th part - Latest recommendations for the max Date
    df_new_month = df_order_block_report[(df_order_block_report['date'] == df_order_block_report['date'].max()) & (df_order_block_report['obligor_code'].isin(active_customers))]
    print("\nCustomers with New Credit Limit: {}".format(df_new_month.obligor_code.nunique()))
    logger.debug("\nCustomers with New Credit Limit: %s", df_new_month.obligor_code.nunique())
    
    ################################################################################################################
    # 5th Part - Combining 3rd part and 4th Part
    # First Appending 2nd Max Date with all the Obligors (Old Predictions & New Predictions) with the new predictions from the new report
    # Appending (3.2) + (4) with (3.1) - Not Part of the system now
    df_last_two_months = df_previous_month._append(df_new_month, ignore_index=True)

    ################################################################################################################
    # 6th Part - Combine 5 with 2, i.e Appending inactive customers with active customers
    df_last_two_months = df_last_two_months._append(df_degraded, ignore_index=True)
    df_last_two_months = df_last_two_months.sort_values(['obligor_code', 'date'])
    df_last_two_months.reset_index(drop=True, inplace=True)
    print("\nRecommended Credit Limit provided for {} Customers".format(df_last_two_months.obligor_code.nunique()))
    logger.debug("\nRecommended Credit Limit provided for %s Customers", df_last_two_months.obligor_code.nunique())

    ################################################################################################################
    # 7th Part - Combine 1st & 6th part
    df = df_prev_order_block_till_max._append(df_last_two_months, ignore_index=True)
    df = df.sort_values(['obligor_code', 'date'])
    df.reset_index(drop=True, inplace=True)

    ################################################################################################################
    ################################################################################################################

    print("\n\nShape of Updated Order Block Data: ", df.shape)
    print("Obligor Count of Updated Order Block Data: ", df.obligor_code.nunique())
    logger.debug("\n\nShape of Updated Predicted Order Block Data: %s", df.shape)
    logger.debug("\nObligor Count of Updated Predicted Order Block Data: %s", df.obligor_code.nunique())

    return df

# Update previous month's Rating, ratings_5_scale, recommended_credit_limit, dso_pred, sales_pred, sales_multiplier
def update_recommendation(df_order_block_report, df_prev_order_block, df_sales, active_customers):
    
    # Current Snap
    current_snap = df_order_block_report.date.max()

    # Get all Inactive Customers
    obl_exclude = obligors_to_exclude(df_sales)

    ################################################################################################################
    # 1st Part - Degrade the recommended credit limits for all the inactive customers

    # Get previous max snaps of all obligors to be excluded for degrading their credit limits
    df_obl_exclude = df_prev_order_block[df_prev_order_block['obligor_code'].isin(obl_exclude)].reset_index()
    df_obl_max_date = df_obl_exclude.groupby('obligor_code')['date'].max().reset_index()
    df_to_be_degraded = pd.merge(df_obl_exclude, df_obl_max_date, how='inner', on=['obligor_code', 'date'])

    # Degrade their credit limits
    df_degraded = degrade_credit_limits(df_to_be_degraded, current_snap)
    print("\nCustomers with Degraded Credit Limit: {}".format(df_degraded.obligor_code.nunique()))
    logger.debug("\nCustomers with Degraded Credit Limit: %s", df_degraded.obligor_code.nunique())

    ################################################################################################################
    # 2nd part - Latest recommendations for the max Date
    df_new_month = df_order_block_report[(df_order_block_report['date'] == df_order_block_report['date'].max()) & (df_order_block_report['obligor_code'].isin(active_customers))]
    print("\nCustomers with New Credit Limit: {}".format(df_new_month.obligor_code.nunique()))
    logger.debug("\nCustomers with New Credit Limit: %s", df_new_month.obligor_code.nunique())
    
    ################################################################################################################
    # 3rd Part - Combining 2nd part and 3rd Part
    df_last_month = df_new_month._append(df_degraded, ignore_index=True)

    ################################################################################################################
    # 4th Part - Combine Previous Predictions & 3rd part <Previous Predictions with the new predictions>

    df = df_prev_order_block._append(df_last_month, ignore_index=True)
    df = df.sort_values(['obligor_code', 'date'])
    df.reset_index(drop=True, inplace=True)

    ################################################################################################################
    ################################################################################################################

    print("\n\nCredit Limit set for {} Customers in the current month".format(df_last_month.obligor_code.nunique()))
    print("\n\nShape of Updated Order Block Data: ", df.shape)
    print("Obligor Count of Updated Order Block Data: ", df.obligor_code.nunique())
    logger.debug("\n\nCredit Limit set for %s Customers in the current month", df_last_month.obligor_code.nunique())
    logger.debug("\n\nShape of Updated Predicted Order Block Data: %s", df.shape)
    logger.debug("\nObligor Count of Updated Predicted Order Block Data: %s", df.obligor_code.nunique())

    return df

# Create the Ratings Copy & Model Outputs Copy Table & Save it
def create_outputs_n_save(df_final_order_block):
    # Final Order Block Report
    df_final_order_block_report = df_final_order_block[['obligor_code', 'date', 'rating', 'rating_5_scale', 'recommended_credit_limit', 'dso_pred', 'sales_pred', 'sales_multiplier', 'degraded']]

    logger.debug("Recommendations Updated")
    print('\nRecommendations Updated')

    # Final Ratings File
    df_ratings = df_final_order_block[['date', 'rating', 'rating_5_scale', 'obligor_code', 'recommended_credit_limit', 'degraded']]

    # Save the Outputs to be pushed into the production
    df_ratings.to_csv(ratings_file, index=False)
    print('\nRatings File Created')
    logger.debug("Ratings File Created")
    df_final_order_block_report.to_csv(order_block_file, index=False)
    logger.debug("Recommendations File Created")
    df.to_csv(full_output, index=False)
    print('\nRecommendations File Created')

    return

if __name__ == "__main__":
    # Load the input files and Preprocess the data
    df, df_sales_forecast = load_preprocess_data()

    # Assigning Credit Segments & Recommended Credit Limit
    df = credit_segment(df)

    # Assign Ratings & Rating 5 Scale
    df = assign_ratings(df)

    # Get all Active Customers
    active_customers = obligors_to_score(df_sales_forecast)

    # Get the previous Order block report & the New Order Block Report
    df_order_block_report, df_prev_order_block = get_order_block_reports(df, active_customers)

    # Update the Recommendations
    df_final_order_block = update_recommendation(df_order_block_report, df_prev_order_block, df_sales_forecast, active_customers)

    # Update the Rating 5 Scale when it is negative with NaN
    df_final_order_block['rating_5_scale'] = np.where(df_final_order_block['rating_5_scale'] < 0, np.nan, df_final_order_block['rating_5_scale'])

    # Create the Ratings Copy & Model Outputs Copy Table & Save it
    create_outputs_n_save(df_final_order_block)

    print('Code Completed')