import pdb
import warnings        
import pandas as pd
from datetime import datetime

from config_connection_varirables import conn, schema_name

warnings.filterwarnings('ignore')

# Input Data
sales_error_metrics = 'sales_model/model_dumps/error_metrics.csv'
dso_error_metrics    = 'dso_model/model_dumps/error_metrics.csv'

if __name__ == "__main__":
    # # Load the sales_error_metrics Data
    df_sales_error = pd.read_csv(sales_error_metrics)
    df_sales_error['date'] = pd.to_datetime(datetime.now())
    print(df_sales_error)

    df_sales_error.to_sql(name='sales_error_metrics', schema=schema_name,con = conn, if_exists='append', index=False, chunksize=1000)
    print('\nUploaded the sales_error_metrics')

    # # Load the dso_error_metrics Data
    df_dso_error = pd.read_csv(dso_error_metrics)
    df_dso_error['date'] = pd.to_datetime(datetime.now())
    print(df_dso_error)

    df_dso_error.to_sql(name='dso_error_metrics', schema=schema_name,con = conn, if_exists='append', index=False, chunksize=1000)
    print('\nUploaded the dso_error_metrics')