import pdb
import warnings        
import pandas as pd
from datetime import datetime, date
from dateutil.relativedelta import relativedelta

# import sqlalchemy
from sqlalchemy.sql import text
# from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

from config_connection_varirables import conn, session

warnings.filterwarnings('ignore')

# DB Engine Configuration
# engine = 'postgresql://ro_user:bdfsfserygfyvbdk@localhost:1200/webserver_db'

# Configure Connection
# conn = sqlalchemy.create_engine(engine)

# Base = declarative_base()
# Session = sessionmaker(bind=conn)
# session = Session()


# Get today
today = date.today()
current_month = today.strftime("%B")
current_month_start = datetime.strftime(today.replace(day=1), '%Y-%m-%d')

last_month_start = datetime.strftime(today.replace(day=1) - relativedelta(months=1), '%Y-%m-%d')

# Input Data
ratings_copy_file = 'Data/Output/scored_ratings.csv'
model_copy_file = 'Data/Output/scored_ratings_order_block_report.csv'


if __name__ == "__main__":
    print('\nCurrent Date: ', today)
    print('\nUpdating the credit limits for ', current_month)
    print('\nCurrent Month Start Date: ', current_month_start)
    print('\nLast Month Start Date: ', last_month_start)

    # Delete Data From Ratings Copy Table
    # Restart the Identity of R atings Table
    session.execute(text(open('sql_scripts/1_delete_truncate_ratings_copy.sql', "r").read()))

# try:
#     # Begin a transaction
#     with session.begin():
#         # Execute the SQL script from a file
#         script = open('sql_scripts/1_delete_truncate_ratings_copy.sql', 'r').read()
#         session.execute(text(script))
    
#     # Commit the transaction
#     session.commit()
# except Exception as e:
#     # Handle the error and roll back the transaction
#     print("An error occurred:", str(e))
#     session.rollback()

    # # Load the scored_ratings Data
    df_ratings_copy = pd.read_csv(ratings_copy_file)

    # Upload scored_ratings to ratings_copy table
    df_ratings_copy.to_sql(name='ratings_copy', con = conn, if_exists='append', index=False, chunksize=1000)
    print('\nUploaded the scored_ratings to ratings_copy table')

    # Insert data into ratings table from ratings_copy table
    # Restart the Identity for recommended_credit_limits table
    session.execute(text(open('sql_scripts/2_insert_into_ratings_table.sql', "r").read()))
    session.commit()
    
    # Inserting data into recommended_credit_limits table from ratings_copy table for the latest month
    insert_query = """insert
                        into
                        recommended_credit_limits (client_id ,
                        sys_obligor_code,
                        recommended_limit ,
                        date)
                    select
                        6,
                        concat('6_', obligor_code),
                        recommended_credit_limit,
                        date
                    from
                        ratings_copy rc
                    where
                        date = '""" + current_month_start + """'
                    ;"""
    session.execute(text(insert_query))
    session.commit()

    # Restart the identity for the recommended_credit_limit_histories table
    # Insert Data into recommended_credit_limit_histories table from ratings_copy
    # Update the ratings table using Obligors table & ratings table
    # Update the date in the ratings table
    session.execute(text(open('sql_scripts/3_update_cl_history.sql', "r").read()))
    session.commit()

    # Update the ratings table for the latest month
    insert_query_2 = """insert
                            into
                            ratings(client_id ,
                            sys_obligor_code ,
                            rating_5_scale ,
                            rating ,
                            date)
                        select
                            client_id ,
                            sys_obligor_code ,
                            rating_5_scale ,
                            rating ,
                            '""" + current_month_start + """'
                        from
                            ratings
                        where
                            date = '""" + last_month_start + """';"""
    session.execute(text(insert_query_2))
    session.commit()

    # Delete the model_outputs_copy table
    # Restart the identity of the model_outputs table
    session.execute(text(open('sql_scripts/4_delete_truncate_model_outputs.sql', "r").read()))
    session.commit()

    # Load the scored_ratings_order_block_report Data
    df_model_copy = pd.read_csv(model_copy_file)

    # Upload scored_ratings to ratings_copy table
    df_model_copy.to_sql(name='model_outputs_copy', con = conn, if_exists='append', index=False, chunksize=1000)
    print('\nUploaded the scored_ratings_order_block_report to model_outputs_copy table')

    # Insert data into model_outputs table using model_outputs_copy 
    session.execute(text(open('sql_scripts/5_update_model_outputs_table.sql', "r").read()))
    session.commit()

    # Insert Credit Limits to Obligor Division Credit Limit Table
    session.execute(text(open('sql_scripts/6_insert_into_obligor_division_table.sql', "r").read()))
    session.commit()
    print('\nUploaded the credit limits to Obligor Division Credit Limit Table')

    print('\nCode Complete')