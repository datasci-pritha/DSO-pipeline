import pdb
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from config_connection_varirables import conn, from_date, to_date, logger

# Get aggregated Obligor Sales & Invoice Count
def get_invoices(schema_name):
    # Save Invoice File
    invoice_query = f"""select * from {schema_name}.invoice;"""
    pd.read_sql(sql=invoice_query, con=conn).to_csv('Data/base_data/invoice.csv')

    # Dataframe Required
    df_sales = pd.DataFrame()

    # Query to get Sales from Invoice Data
    query = f"""with inv as
            (select
                obligor_code
                , to_char(post_date, 'YYYYMM') as yyyymm
                , invoice_num
                , sum(amount) as sales
            from {schema_name}.invoice i 
            group by 1, 2, 3
            having sum(amount) != 0
            order by 1, 2, 3
            )
            select 
                obligor_code 
                , yyyymm
                , count(invoice_num) as invoice_count
                , sum(sales) as sales
            from inv
            group by 1, 2
            order by 1, 2;"""
    df_sales = pd.read_sql(sql=query, con=conn)

    return df_sales

# Get aggregated Obligor Collection
def get_collection(schema_name):
    # Save Collection File
    collection_query = f"""select * from {schema_name}.collection;"""
    pd.read_sql(sql=collection_query, con=conn).to_csv('Data/base_data/collection.csv')

    # Dataframe Required
    df_collection = pd.DataFrame()

    # Query to get Collection from Collection Data
    query = f"""with coll as
            (select 
                obligor_code
                , to_char(post_date, 'YYYYMM') as yyyymm
                , transaction_number 
                , -1 * sum(amount) as collection
            from {schema_name}.collection c 
            group by 1, 2, 3
            having 
                sum(amount) != 0
            order by 1, 2
            )
            select 
                obligor_code 
                , yyyymm
                , sum(collection) as collections
            from coll
            group by 1, 2
            order by 1, 2;"""
    df_collection = pd.read_sql(sql=query, con=conn)

    return df_collection

# Get aggregated Obligor Adjustments
def get_adjustment(schema_name):
    # Save Invoice File
    invoice_query = f"""select * from {schema_name}.adjustment;"""
    pd.read_sql(sql=invoice_query, con=conn).to_csv('Data/base_data/adjustment.csv')

    # Dataframe Required
    df_sales = pd.DataFrame()

    # Query to get Sales from Invoice Data
    query = f"""with inv as
            (select
                obligor_code
                , to_char(post_date, 'YYYYMM') as yyyymm
                , transaction_number
                , sum(amount) as sales
            from {schema_name}.adjustment i 
            group by 1, 2, 3
            having sum(amount) != 0
            order by 1, 2, 3
            )
            select 
                obligor_code 
                , yyyymm
                , sum(sales) as adjustments
            from inv
            group by 1, 2
            order by 1, 2;"""
    df_sales = pd.read_sql(sql=query, con=conn)

    return df_sales

# Get Obligor Snaps
def get_debtor_level_metrics(schema_name):
    # Get aggregated Obligor Sales
    df_sales = get_invoices(schema_name)

    # Get aggregated Obligor Collections
    df_collection = get_collection(schema_name)

    # Get aggregated Obligor Adjustments
    df_adjustment = get_adjustment(schema_name)

    # Merge Sales & Collection Data & Adjustments
    df = pd.merge(df_sales, df_adjustment, how='outer', on=['obligor_code', 'yyyymm'])
    df = pd.merge(df, df_collection, how='outer', on=['obligor_code', 'yyyymm'])

    # Get all Obligors & possible snaps
    min_snap = datetime.strptime(df.yyyymm.min(), '%Y%m')
    obligors_min_snap = df.groupby('obligor_code').agg({'yyyymm':['min', 'max']}).reset_index()
    obligors_min_snap.columns = obligors_min_snap.columns.map(''.join)
    snaps = pd.date_range(start=min_snap, end=datetime.strftime(datetime.strptime(to_date, '%Y-%m-%d') + timedelta(days=1), '%Y-%m-%d'), freq='MS').to_frame().reset_index(drop=True)
    snaps[0] = snaps[0].transform(lambda x: datetime.strftime(x, '%Y%m'))

    # Create key to cross join
    snaps['key'] = 0
    obligors_min_snap['key'] = 0
    obligor_snaps = pd.merge(obligors_min_snap, snaps, on=['key'], how='outer')

    # Rename the snap column
    obligor_snaps = obligor_snaps.rename(columns={0:'yyyymm'}).reset_index(drop=True)

    # Merge with Customer Data
    df = pd.merge(obligor_snaps, df, how='outer', on=['obligor_code', 'yyyymm'])

    # Replace all Nan with zero
    df.fillna(0, inplace=True)

    # Remove all snaps before the min snaps 
    df = df[df['yyyymm'] >= df['yyyymmmin']].reset_index(drop=True)

    # Sort Values by Obligor Code, Invoice YYYYMM
    df = df.sort_values(['obligor_code', 'yyyymm']).reset_index(drop=True)

    # Create sales till now, collection till now, end_balance, previous_balance & beyond_max_snap
    df['sales_till_now'] = df.groupby(['obligor_code'])['sales'].cumsum()
    df['adjustments_till_now'] = df.groupby(['obligor_code'])['adjustments'].cumsum()
    df['collection_till_now'] = df.groupby(['obligor_code'])['collections'].cumsum()
    df['end_balance'] = df['sales_till_now'] + df['adjustments_till_now'] - df['collection_till_now']
    df['previous_balance'] = df.groupby(['obligor_code'])['end_balance'].shift(1)
    df['beyond_max_snap'] = np.where((df['yyyymm']>df['yyyymmmax']) & (df['end_balance']==0), 1, 0)

    # Replace all Nan with zero
    df.fillna(0, inplace=True)

    # Remove all snaps before from_date & to_date
    min_snap_to_be_considered = datetime.strftime(datetime.strptime(from_date, '%Y-%m-%d'), '%Y%m')
    max_snap_to_be_considered = datetime.strftime(datetime.strptime(to_date, '%Y-%m-%d') + timedelta(days=1), '%Y%m')
    df = df[(df['yyyymm'] >= min_snap_to_be_considered) & (df['yyyymm'] < max_snap_to_be_considered)].reset_index(drop=True)

    # Rename the columns before pushing to the DB
    df.rename(columns={'collections':'paid_amt', 'invoice_count':'num_invoices', 'yyyymm':'invoice_yyyymm'}, inplace=True)

    # Max Snap
    max_snap = df[df['beyond_max_snap']==0].groupby('obligor_code').agg({'invoice_yyyymm':['max']}).reset_index()
    max_snap.columns = max_snap.columns.map(''.join)

    # Creating obligors_min_max_snaps
    obligors_min_max_snaps = pd.merge(obligors_min_snap[['obligor_code', 'yyyymmmin']],
                                        max_snap[['obligor_code', 'invoice_yyyymmmax']], on=['obligor_code'])
    obligors_min_max_snaps.rename(columns={'yyyymmmin':'min_yyyymm', 'max_snap':'max_yyyymm'})

    # Drop yyyymmmin, yyyymmmax
    df.drop(['yyyymmmin', 'yyyymmmax'], axis=1, inplace=True)

    # Save the Base File
    df.to_csv('Data/base_data/customer_snap_data.csv', index=False)

    # Push to DB
    df[['obligor_code', 'invoice_yyyymm', 'sales', 'paid_amt', 'end_balance', 
        'previous_balance', 'num_invoices']].to_sql(name='debtor_level_metrics',schema=schema_name, con = conn, if_exists='replace', index=False)
    obligors_min_max_snaps.to_sql(name='obligors_min_max_snaps',schema=schema_name, con = conn, if_exists='replace', index=False)
    print('\nPushed Debtor Level Metrics & Obligor Min Max Snap to DB\n')
    logger.debug("\nPushed Customer Snap Data, Debtor Level Metrics & Obligor Min Max Snap to DB")

    return 

if __name__ == "__main__":
    # Create Model Input Tables - Calls get_debtor_level_metrics first
    # create_model_input_tables()

    # Creates obligor level data from invoice, collection and adjustments
    get_debtor_level_metrics()