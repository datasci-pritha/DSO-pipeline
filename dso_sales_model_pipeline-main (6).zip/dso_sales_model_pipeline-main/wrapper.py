import pdb
import time
import warnings                                 
import pandas as pd

warnings.filterwarnings('ignore')

from get_obligor_snap_level_data import get_debtor_level_metrics
import config_connection_varirables
from config_connection_varirables import model_files, model_inputs_sql_file, base_table_file
from config_connection_varirables import db_name, conn, session, from_date, to_date, logger,start_execution_from
from config_connection_varirables import schema_name, schema_to_be_dropped
from sqlalchemy.sql import text
from sendgrid_helper import send_all

if __name__ == "__main__":
    try:
        if (start_execution_from == 'wrapper' or start_execution_from == 'till_model_build' or start_execution_from == 'schema_creation'):
            
            ################## Schema Creation ##################

            logger.debug("Create the Schema and Copy the necessary tables For Model Building")
            t0 = time.time()

            # Drop Schema if exists
            drop_schema_query = f"DROP SCHEMA IF EXISTS {schema_name} CASCADE;"
            session.execute(text(drop_schema_query))
            session.commit()

            # Create the schema
            create_schema_query = f"CREATE SCHEMA {schema_name};"

            session.execute(text(create_schema_query))
        
            # Move tables to the new schema
            copy_tables_query = f"""
            CREATE TABLE {schema_name}.accounting_items AS SELECT * FROM public.accounting_items;
            CREATE TABLE {schema_name}.model_outputs_copy AS Select * from public.model_outputs_copy;
            CREATE TABLE {schema_name}.sales_ledger AS Select * from public.sales_ledger;
            CREATE TABLE {schema_name}.orders AS Select * from public.orders;
            CREATE TABLE {schema_name}.obligor_penalties AS Select * from public.obligor_penalties;
            CREATE TABLE {schema_name}.borrowers AS Select * from public.borrowers;
            CREATE TABLE {schema_name}.obligors AS SELECT * FROM public.obligors;
            CREATE TABLE {schema_name}.customer_collection_forecast AS Select * from public.customer_collection_forecast;
            CREATE TABLE {schema_name}.exclusion_collection_forecast AS Select * from public.exclusion_collection_forecast;
            """
            session.execute(text(copy_tables_query))
            session.commit()

            # Drop Schema created 6 months back 
            drop_schema_6m_query = f"DROP SCHEMA IF EXISTS {schema_to_be_dropped} CASCADE;"
            session.execute(text(drop_schema_6m_query))
            session.commit()

            print("\n\n\nTime Taken to Create Schema and Copy Tables: ")
            print(time.time() - t0)

        if (start_execution_from == 'wrapper' or start_execution_from == 'till_model_build' or start_execution_from == 'base_data_generation'):
            
            ################## BASE DATA GENERATION ##################

            logger.debug("Snapshots created from %s to %s", from_date, to_date)
            print('\nDB Name: ', db_name)
            print('\nSnapshots created from ', from_date,' to ',to_date)
            t1 = time.time()

            with open(base_table_file, "r") as sql_file:
                sql_query = sql_file.read()
            
            sql_query = sql_query.replace("{{SCHEMA_NAME}}", schema_name)

            session.execute(text(sql_query))

            session.commit()
            print('\nInvoice & Collection Table Created')
            print("\n\n\nTime Taken to Create Invoice & Collection Table: ")
            print(time.time() - t1)

            t2 = time.time()
            get_debtor_level_metrics(schema_name)
            print("\n\n\nTime Taken to Create Debtor Level Metrics: ")
            print(time.time() - t2)
            

        if (start_execution_from == 'wrapper' or start_execution_from == 'till_model_build' or start_execution_from == 'model_inputs_generation'):

            ################## MODEL INPUTS GENERATION ##################

            t3 = time.time()
            # Create and insert values into the required tables using sql script (debtor_level_metrics to model_inputs and sales_forecast)
        
            with open(model_inputs_sql_file, "r") as sql_file:
                sql_query_inputs = sql_file.read()
            
            sql_query_inputs = sql_query_inputs.replace("{{SCHEMA_NAME}}", schema_name)
            
            session.execute(text(sql_query_inputs))
            session.commit()
            logger.debug("\nModel Inputs and Sales Forecast Tables created")
            print("\n\n\nTime Taken to Create and Populate payment_behaviour_table and sales_forecast : ")
            print(time.time() - t3)

        if (start_execution_from == 'wrapper' or start_execution_from == 'till_model_build' or start_execution_from == 'extract_model_inputs'):

            ################## MODEL INPUTS EXTRACTION ##################

            t4 = time.time()
            # Model Building Execution
            print("\n\n\nStarts Model Building Process")

            # Exporting Model inputs and Sales Forecast
            
            df_target = pd.read_sql_query(sql=f"select * from {schema_name}.sales_forecast_data", con=conn)
            df_model_input = pd.read_sql_query(sql=f"select * from {schema_name}.payment_behaviour_table", con=conn)

            df_target.to_csv('Data/Model Inputs/sales_forecast_data.csv', index=False)
            df_model_input.to_csv('Data/Model Inputs/payment_behaviour_table.csv', index=False)

            print("\n\n\nExtracted Input Data From the DB")
            logger.debug("Extracted Input Data From the DB")
            print("\n\n\nTime Taken to Extract payment_behaviour_table and sales_forecast : ")
            print(time.time() - t4)

        if (start_execution_from == 'wrapper' or start_execution_from == 'build_model' or start_execution_from == 'sales'):

            ################## SALES MODEL BUILDING ##################

            t5 = time.time()
            for file_name in model_files:
                # if file_name[0:2] not in ('9_', '10'):
                file_path = 'sales_model/' + 'b' + file_name + '.py'
                print("\nStarts Executing Sales File: ", file_name)
                logger.debug("\n\n\n Starts Executing Sales File: %s \n\n\n", file_name)
                exec(open(file_path).read())
            
            # Rebuild the Model if the accuracy is not acceptable, Notify 'Sales Model Accuracy is not Acceptable>
            if config_connection_varirables.notify == True:
                # Notify
                # pdb.set_trace()
                send_all('Sales Model Accuracy is not Acceptable')
                config_connection_varirables.notify = False

            print("\n\n\nFinished Sales Model Building and Sales Predictions are ready\n\n\n")
            logger.debug("Finished Sales Model Building and Sales Predictions are ready")

            print("Time Taken to Build Sales Model : ")
            print(time.time() - t5)

        if (start_execution_from == 'wrapper' or start_execution_from == 'build_model' or start_execution_from == 'dso'):

            ################## DSO MODEL BUILDING ##################
            t6 = time.time()
            for file_name in model_files:
                file_path = 'dso_model/' + 'a' + file_name + '.py'
                print("\nStarts Executing DSO File: ", file_name)
                logger.debug("\n\n\n Starts Executing DSO File: %s \n\n\n ", file_name)
                exec(open(file_path).read())

            # Rebuild the Model if the accuracy is not acceptable, Notify 'DSO Model Accuracy is not Acceptable>
            if config_connection_varirables.notify == True:
                # Notify
                # pdb.set_trace()
                send_all('DSO Model Accuracy is not Acceptable')
                config_connection_varirables.notify = False

            print("\n\n\nFinished DSO Model Building and DSO Predictions are ready\n\n\n")
            logger.debug("Finished DSO Model Building and DSO Predictions are ready")

            print("\nTime Taken to Build DSO Model : ")
            print(time.time() - t6)

        if (start_execution_from == 'wrapper' or start_execution_from == 'build_model' or start_execution_from == 'credit_limit_rating_creation'):

            ################## RECOMMEND CREDIT LIMITS ##################

            t8 = time.time()
            # Get files ready to be sent to production
            exec(open('credit_limit_rating_creation.py').read())

            print("\n\nOutput files ready to be pushed into production\n\n")
            logger.debug("\n\n\n Output files ready to be pushed into production \n\n\n ")
            print("\nTime Taken to Create Recomended Credit Limit : ")
            print(time.time() - t8)

            # Notify 'All the Active customers are not scored>
            if config_connection_varirables.notify == True:
                # Notify
                # pdb.set_trace()
                send_all('All the Active customers are not scored')
                config_connection_varirables.notify = False
        
        if (start_execution_from == 'wrapper' or start_execution_from == 'build_model' or start_execution_from == 'final_push'):
            print('Start pushing')
            schema_name
            t7 = time.time()
            # Get files ready to be sent to production
            exec(open('Pushing_error_metrics.py').read())

            t9 = time.time()
            # Get files ready to be sent to production
            exec(open('final_push_to_production.py').read())

            if start_execution_from == 'wrapper':
                print("Time Taken to run the whole pipeline : {} Minutes".format(round((time.time() - t0)/60), 2))

        session.close()
        print("Session Closed")
        print('\n\nCode Complete\n\n')
    except Exception as error:
        # Notify 'Wrapper File broke down in between'
        # pdb.set_trace()
        print(error)
        send_all('Wrapper File broke down in between')
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------- #
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------- #
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------- #
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------- #
