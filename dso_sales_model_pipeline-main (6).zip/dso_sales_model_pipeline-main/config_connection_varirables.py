import logging
import sqlalchemy
import os

from sqlalchemy.orm import sessionmaker
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from sqlalchemy.ext.declarative import declarative_base
from dotenv import load_dotenv

load_dotenv()
#########################################################################################################################
########################################### CONFIGURE ALL THE VARIABLES BELOW ###########################################
#########################################################################################################################

# Get today
today = datetime.today()
month = today.strftime("%B").lower()

#######################################################################
########################### DB CREDENTIALS ############################
#######################################################################

# DB Credentials Configuration
db_dialect = os.getenv('DB_DIALECT')
db_username = os.getenv('DB_USERNAME')
db_password = os.getenv('DB_PASSWORD')
db_host = os.getenv('DB_HOST')
db_name = os.getenv('DB_NAME')

# DB Engine Path
engine = 'postgresql://' + db_username + ':' + db_password + '@' + db_host + '/' + db_name

# Configure Connection
conn = sqlalchemy.create_engine(engine)

Base = declarative_base()
Session = sessionmaker(bind=conn)
session = Session()

# Schema Name Creation
schema_name = f"healthium_{today.strftime('%Y_%m')}"

# Schema to be Dropped
month_to_be_dropped = datetime.strftime(today - relativedelta(months=6), '%Y_%m')
schema_to_be_dropped = f"healthium_{month_to_be_dropped}"

#######################################################################
####################### MODEL VARIABLES & FILES #######################
#######################################################################

# Snaps to be created from
from_date = '2017-05-01'

# Snaps to be created till (Example if predicting on 1st February, 2020; to_date will be '2020-01-31')
# Make sure this script is run on 1st of every month else manually provide the to_date
# to_date = '2021-12-31'
if datetime.strftime(today, '%d') == '01':
    to_date = datetime.strftime(today - timedelta(days=1), '%Y-%m-%d')
else:
    to_date = datetime.strftime(today.replace(day=1) - timedelta(days=1), '%Y-%m-%d')

# Model Input Generation SQL File
model_inputs_sql_file = 'sql_scripts/model_input.sql'
base_table_file = 'sql_scripts/create_base_tables.sql'

# Save Intermediate Modelling Files
save_intermediate_files = True

# Create plots
plot_graphs = False

# Flag to notify
notify = False

# Model Files
model_files = [
                '1_filter_create_variables_data_splitting', 
                '2_flooring_capping', 
                '3_normalization',
                '4_remove_multicollinearity', 
                '5_variable_selection', 
                '6_get_important_variables', 
                '7_preprocess_test_data', 
                '8_xgboost_model_built_on_train_validated_on_test',
                '9_final_xgboost_model_built_on_build_sample'
                ]

#######################################################################
############################ Execution Flow ###########################
#######################################################################

# To Execute from different parts of the wrapperk
start_execution_from = 'wrapper'                           # Executes the whole wrapper
#start_execution_from = 'schema_creation'                    # Creates the schema and copies tables
#start_execution_from = 'base_data_generation'               # Executes Base Data Generation 
#start_execution_from = 'model_inputs_generation'            # Executes Model Data Generation
#start_execution_from = 'extract_model_inputs'               # Creates Model Input Tables
#start_execution_from = 'till_model_build'                   # Executes Till Model Building
#start_execution_from = 'sales'                             # Executes Sales Model
# start_execution_from = 'dso'                               # Executes DSO Model
#start_execution_from = 'build_model'                        # Executes Sales & DSO Model
# start_execution_from = 'credit_limit_rating_creation'      # Executes Final Prediction which is pushed to the production
# start_execution_from = 'final_push'                        # Pushes the forecast and credit limits to production DB

#######################################################################
########################### Log Configuration #########################
#######################################################################

log_file_name = "log_model.log"
# level = "DEBUG"
format = "%(filename)s : %(asctime)s : %(funcName)s : %(levelname)s : %(message)s"

#Create and configure logger
logging.basicConfig(filename=log_file_name, format=format, filemode='a') 

#Creating an object 
logger=logging.getLogger()

#Setting the threshold of logger to DEBUG 
# logger.setLevel(logging.INFO) 
logger.setLevel(logging.DEBUG) 

#########################################################################################################################
#########################################################################################################################