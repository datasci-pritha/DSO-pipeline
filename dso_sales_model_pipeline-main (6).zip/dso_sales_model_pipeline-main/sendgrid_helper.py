from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import os
from dotenv import load_dotenv

load_dotenv()

sendgrid_api_key = os.getenv('SENDGRID_API_KEY')
from_smtp_user = os.getenv('WEB_SERVER_SMTP_USERNAME')

# Email from which the email is being sent
from_email = from_smtp_user

def send_all(message):
    to_emails =['deepak@twodotseven.com', 'okker@twodotseven.com', 'akshay@twodotseven.com', 'yazdan@twodotseven.com','aniket@twodotseven.com', 'monitoring@twodotseven.com']
    # to_emails =['akshay@twodotseven.com','okker@twodotseven.com']
    try:
        # Sendgrid API Key
        sg = SendGridAPIClient(
            api_key=sendgrid_api_key)
        message = Mail(
            from_email=from_email,
            to_emails=to_emails,
            subject='Alert from Sales Model',
            html_content='<p>'+message+'</p>'
        )
        response = sg.send(message)
        print(response.status_code)
        print(response.body)
        print(response.headers)
    except Exception as e:
        print("Error sending email: ", str(e))

