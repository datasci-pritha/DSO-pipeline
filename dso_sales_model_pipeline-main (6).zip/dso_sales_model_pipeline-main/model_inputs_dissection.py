import os
import pdb
import warnings
import datetime
import numpy as np
import pandas as pd

input_file = 'Data/Model Inputs/sales_forecast_data.csv'

def obligors_to_exclude(df):
    scored_obligors = obligors_to_score(df)
    df, df_bal_max_invoice = obligor_dissection(df)

    # Get all obligors who has more than 6 snaps
    ob_1 = pd.Series(df['obligor_code'][df['more_than_6_snaps'] == 1].unique()).sort_values().to_list()
    ob_1 = list(map(str, list(set(ob_1))))

    print('\n\nObligors to Exlude')

    print("\nNo of Obligors with more than 6 snaps and not reported in last 6 months: ", df['obligor_code'][df['not_reported_last_6_months'] == 1].nunique())

    print("\nObligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months & has balance in last 6 months: ", df['obligor_code'][df['no_sale_no_collection_has_balance_last_6m'] == 1].nunique())

    print("\nNo of Obligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months & has no outstanding balance: ", df['obligor_code'][df['has_no_outstanding'] == 1].nunique())

    # Remove obligors who are to be scored from the list to get the excluded obligors
    excluded_obligors = list(set(ob_1) - set(scored_obligors))

    print('\nNumber of customers excluded: ', len(excluded_obligors))
    return excluded_obligors

def obligors_to_score(df):

    df, df_bal_max_invoice = obligor_dissection(df)

    print('\n\nObligors to Score')

    # Obligors who has sales in last 6 months
    ob_1 = pd.Series(df['obligor_code'][df['has_sales_in_last_6_months'] == 1].unique()).sort_values().to_list()
    print("\nObligors who has sales in last 6 months: ", len(ob_1))

    # Obligors reported last 6 months & no sales in last 6 months & has repayment in last 6 months
    ob_2 = pd.Series(df['obligor_code'][df['no_sale_has_collection_last_6m'] == 1].unique()).sort_values().to_list()
    print("\nObligors reported last 6 months & no sales in last 6 months & has repayment in last 6 months : ", len(ob_2))

    scored_obligors = ob_1 + ob_2
    scored_obligors = list(map(str, list(set(scored_obligors))))

    print('\nNumber of customers to be Scored: ', len(scored_obligors))
    return scored_obligors

def obligor_dissection(df):
    # Gets the obligor snap Count
    df_snap = df[df['beyond_max_snap'] == 0].groupby(['obligor_code'])['obligor_code'].count().to_frame(name='snap_count').reset_index(level=['obligor_code'])

    # Adding Snap count to the Dataframe
    df = pd.merge(df, df_snap, how='left', left_on=['obligor_code'], right_on = ['obligor_code'])

    # Creation of variable, more_than_6_snaps  which indicates whether an Obligor has more than been present for more than 6 months
    df['more_than_6_snaps'] = np.where(df['snap_count'] >= 6, 1, 0)

    # Gets the last 6 months
    last_6_months = pd.Series(df['invoice_yyyymm'].unique()).sort_values().to_list()[-6:]

    # Get obligors present in last 6 months with more than 6 snap months
    reported_last_6_months = pd.Series(df['obligor_code'][(df['more_than_6_snaps'] == 1) & (df['beyond_max_snap'] == 0) & (df['invoice_yyyymm'].isin(last_6_months))].unique()).sort_values().to_list()

    # Flag to identify obligors present in last 6 months with more than 6 snap months
    df['reported_last_6_months'] = np.where(df['obligor_code'].isin(reported_last_6_months), 1, 0)

    # Obligors who has sales in last 6 months & reported last 6 months
    df_sales = df[(df['reported_last_6_months']==1) & (df['invoice_yyyymm'].isin(last_6_months))].groupby(['obligor_code'])['sales'].agg('sum').to_frame(name='sales_last_6_months').reset_index(level=['obligor_code'])
    df = pd.merge(df, df_sales, how='left', left_on=['obligor_code'], right_on = ['obligor_code'])
    df['has_sales_in_last_6_months'] = np.where(df['sales_last_6_months'] >  0, 1, 0)

    # Obligors who has sales in last 6 months & reported last 6 months & present in last two months
    sales_reported_last_2m = df['obligor_code'][(df['has_sales_in_last_6_months'] == 1) & (df['beyond_max_snap'] == 0) &(df['invoice_yyyymm'].isin(last_6_months[-2:]))].unique()

    # Flag to identify Obligors who has sales in last 6 months & reported last 6 months & present in last two months
    df['reported_last_2m'] = np.where(df['obligor_code'].isin(sales_reported_last_2m), 1, 0)

    # Obligors who has sales in last 6 months & reported last 6 months & not present in last two months
    sales_not_reported_last_2m = df['obligor_code'][(df['has_sales_in_last_6_months'] == 1) & (~df['obligor_code'].isin(sales_reported_last_2m))].unique()
    
    # Flag to identify Obligors who has sales in last 6 months & reported last 6 months & not present in last two months
    df['has_sale_last_6m_not_reported_last_2m'] = np.where(df['obligor_code'].isin(sales_not_reported_last_2m), 1, 0)

    # Obligors reported last 6 months & no sales in last 6 months
    df['has_no_sales_in_last_6_months'] = np.where(df['sales_last_6_months'] <=  0, 1, 0)

    # Obligors reported last 6 months & no sales in last 6 months & has repayment in last 6 months
    df_repayment = df[(df['has_no_sales_in_last_6_months']==1) & (df['invoice_yyyymm'].isin(last_6_months))].groupby(['obligor_code'])['collections'].agg('sum').to_frame(name='collection_last_6_months').reset_index(level=['obligor_code'])
    df = pd.merge(df, df_repayment, how='left', left_on=['obligor_code'], right_on = ['obligor_code'])
    df['no_sale_has_collection_last_6m'] = np.where(df['collection_last_6_months'] >  0, 1, 0)

    # Obligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months
    df['no_sales_no_collection_last_6_months'] = np.where(df['collection_last_6_months'] <=  0, 1, 0)

    # Obligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months & has outstanding balance
    df_balance = df[(df['no_sales_no_collection_last_6_months']==1) & (df['invoice_yyyymm'].isin(last_6_months))].groupby(['obligor_code'])['balance'].agg('sum').to_frame(name='balance_last_6_months').reset_index(level=['obligor_code'])
    df = pd.merge(df, df_balance, how='left', left_on=['obligor_code'], right_on = ['obligor_code'])
    df['no_sale_no_collection_has_balance_last_6m'] = np.where(df['balance_last_6_months'] >  0, 1, 0)
    has_outstanding = pd.Series(df['obligor_code'][df['no_sale_no_collection_has_balance_last_6m'] == 1].unique()).sort_values().to_list()
    
    # Obligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months & has no outstanding balance
    has_no_outstanding = pd.Series(df['obligor_code'][(df['no_sales_no_collection_last_6_months'] == 1) & (~df['obligor_code'].isin(has_outstanding))].unique()).sort_values().to_list()

    # Flag to identify Obligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months & has no outstanding balance
    df['has_no_outstanding'] = np.where(df['obligor_code'].isin(has_no_outstanding), 1, 0)

    # Get obligors not present in last 6 months but has more than 6 snap months
    not_reported_last_6_months = pd.Series(df['obligor_code'][(df['more_than_6_snaps'] == 1) & (~df['obligor_code'].isin(reported_last_6_months))].unique()).sort_values().to_list()

    # Flag to identify obligors not present in last 6 months with more than 6 snap months
    df['not_reported_last_6_months'] = np.where(df['obligor_code'].isin(not_reported_last_6_months), 1, 0)

    # Get obligors not present in last 6 months but has more than 6 snap months & outstanding Balance in the final snap
    df_max_invoice = df[(df['not_reported_last_6_months'] == 1) & (df['beyond_max_snap'] == 0)].groupby(['obligor_code'])['invoice_yyyymm'].agg('max').to_frame(name='max_invoice_yyyymm').reset_index(level=['obligor_code'])
    df_bal_max_invoice = pd.merge(df, df_max_invoice, how='inner', left_on=['obligor_code', 'invoice_yyyymm'], right_on = ['obligor_code', 'max_invoice_yyyymm'])
    
    return df, df_bal_max_invoice

if __name__ == "__main__":
    df = pd.read_csv(input_file, usecols=['obligor_code', 'invoice_yyyymm', 'sales', 'collections', 'balance', 'beyond_max_snap'])


    # # For Testing Purposes
    # excluded_obligors = obligors_to_exclude(df)
    # scored_obligors = obligors_to_score(df)

    df, df_bal_max_invoice = obligor_dissection(df)

    print("\nInitial Number of Obligors: ", df['obligor_code'].nunique()) 

    print("\nNo of Obligors with more than 6 snaps: ", df['obligor_code'][df['more_than_6_snaps']==1].nunique())

    print("\nNo of Obligors with more than 6 snaps and was reported in last 6 months: ", df['obligor_code'][df['reported_last_6_months'] == 1].nunique())

    print("\nObligors who has sales in last 6 months & reported last 6 months: ", df['obligor_code'][df['has_sales_in_last_6_months'] == 1].nunique())

    print("\nObligors who has sales in last 6 months & reported in last 2 months: ", df['obligor_code'][df['reported_last_2m'] == 1].nunique())

    print("\nObligors who has sales in last 6 months & not reported in last 2 months: ", df['obligor_code'][df['has_sale_last_6m_not_reported_last_2m'] == 1].nunique())

    print("\nObligors who has no sales in last 6 months & reported last 6 months: ", df['obligor_code'][df['has_no_sales_in_last_6_months'] == 1].nunique())

    print("\nObligors reported last 6 months & no sales in last 6 months & has repayment in last 6 months: ", df['obligor_code'][df['no_sale_has_collection_last_6m'] == 1].nunique())

    print("\nObligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months: ", df['obligor_code'][df['no_sales_no_collection_last_6_months'] == 1].nunique())

    print("\nObligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months & has balance in last 6 months: ", df['obligor_code'][df['no_sale_no_collection_has_balance_last_6m'] == 1].nunique())

    print("\nNo of Obligors reported last 6 months & no sales in last 6 months & has no repayment in last 6 months & has no outstanding balance: ", df['obligor_code'][df['has_no_outstanding'] == 1].nunique())

    print("\nNo of Obligors with more than 6 snaps and not reported in last 6 months: ", df['obligor_code'][df['not_reported_last_6_months'] == 1].nunique())

    print("\nObligors not present in last 6 months but has more than 6 snap months & has no outstanding Balance in the final snap: ", df_bal_max_invoice['obligor_code'].nunique())